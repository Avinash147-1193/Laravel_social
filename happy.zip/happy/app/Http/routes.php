<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/


Route::get('/', [

		'uses' =>'\App\Http\Controllers\HomeController@index',
		'as'=>'home',
    
]);


Route::post('/signup', [

		'uses' =>'UserController@postSignUp',
		'as'=>'signup',
    
]);

Route::get('/dashboard', [

		'uses' =>'postController@getDashboard',
		'as'=>'dashboard',
		'middleware'=>'auth',
		'middleware'=>'web'
    
]);

Route::post('/signin', [

		'uses' =>'UserController@postsignin',
		'as'=>'signin',
    
]);

Route::post('/createpost', [

		'uses' =>'postController@postCreatePost',
		'as'=>'post.create',
    
]);

Route::get('/redirect', [

		'uses' =>'SocialAuthController@redirect',
		'as'=>'redirect',
    
]);

Route::get('/callback', [

		'uses' =>'SocialAuthController@callback',
		'as'=>'callback',
    
]);

Route::get('/logout', [

		'uses' =>'UserController@logout',
		'as'=>'logout',
    
]);

Route::get('/postsBycateg1', [

		'uses' =>'postController@getDash1',
		'as'=>'postsBycateg1',
    
]);

Route::get('/postsBycateg2', [

		'uses' =>'postController@getDash2',
		'as'=>'postsBycateg2',
    
]);

Route::get('/postsBycateg3', [

		'uses' =>'postController@getDash3',
		'as'=>'postsBycateg3',
    
]);

Route::get('/postsBycateg4', [

		'uses' =>'postController@getDash4',
		'as'=>'postsBycateg4',
    
]);

