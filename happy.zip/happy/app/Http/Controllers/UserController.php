<?php
namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;


class UserController extends Controller
{
    

	public function postSignUp(Request $request)
	{
		$this->validate($request, [
           'email'=>'required|email|unique:users',
           'first_name'=>'required|max:120',
           'last_name'=>'required|max:120',
           'password'=>'required|min:5'
			]);

	    $email=$request['email'];
	    $first_name=$request['first_name'];
	    $last_name=$request['last_name'];
	    $password=bcrypt($request['password']);

	    $user = new User();
	    $user->email=$email;
	    $user->first_name=$first_name;
	    $user->last_name=$last_name;
	    $user->password=$password;
        
	    $user->save();

	    Auth::login($user);
	    

	    return redirect()->route('dashboard');
	}

	public function logout() {

    Auth::logout();
    return redirect()->route('home');

    }

	public function postsignin(Request $request)
	{    
		$this->validate($request, [
           'email'=>'required|email',
           
           'password'=>'required|min:5'
			]);

		
         $email=$request['email'];
		
		 $password=$request['password'];
		  

		if(Auth::attempt(['email' => $email, 'password' => $password])){
			
			 
			
			return redirect()->route('dashboard');
	               
		}

       else{
       	   return redirect()->route('home');
       }
	}

	
}