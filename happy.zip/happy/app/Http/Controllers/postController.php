<?php
namespace App\Http\Controllers;

use App\Http\Controllers\UserController;
use App\Post;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;


class PostController extends Controller
{
     public function getDash1()
    {	
        $ct='Feeding & Nursing';


       
        $posts=Post::where('category', $ct)->get();

    	

    	return view('dashboard',['posts'=>$posts]);
    }
	
	 public function getDash2()
    {	
        $ct='Bath & Skin Care';


       
         $posts=Post::where('category', $ct)->get();

    	

    	return view('dashboard',['posts'=>$posts]);
    }
	
	 public function getDash3()
    {	
        $ct='Health & Safety';


       
         $posts=Post::where('category', $ct)->get();


    	return view('dashboard',['posts'=>$posts]);
    }
	
	 public function getDash4()
    {	
        $ct='Baby Gear';


       
        $posts=Post::where('category', $ct)->get();

    	

    	return view('dashboard',['posts'=>$posts]);
    }
	
	public function getDashboard()
    {	
        

    	$posts=Post::orderBy('id', 'DESC')->get();

    	return view('dashboard',['posts'=>$posts]);
    }


	public function postCreatePost(Request $request)
	
	{    
		$this->validate($request,[
				'feedBox'=>'required|max:300',
				'categ'=>'required'
			]);
		$post=new Post();
		$post->body= $request['feedBox'];
		$post->category=$request['categ'];
		$message='There was some error! Try after some time.';
		if($request->user()->posts()->save($post)){
			$message='Post successfully created!';
		}
		return redirect()->route('dashboard')->with(['message'=>$message]);
	}

}


