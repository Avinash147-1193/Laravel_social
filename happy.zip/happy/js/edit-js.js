


jQuery(function($){
	
$('a.mobilemenu').click(function(){
         $('.nav-sup').slideToggle('slow');
});

$('.tophead').find('.details').find('.mobilemenu').on('click', function(){
	$('.mobilemenu').toggleClass('active');
});

$('a.gotosec1').click(function(){
         $('.controls ul li a').removeClass('active');
         $('.controls ul li:nth-child(2) a').addClass('active');

});
$('a.gotosec2').click(function(){
         $('.controls ul li a').removeClass('active');
         $('.controls ul li:nth-child(3) a').addClass('active');

});


var wow = new WOW(
  {
    boxClass:     'wow',      // animated element css class (default is wow)
    animateClass: 'animated', // animation css class (default is animated)
    offset:       0,          // distance to the element when triggering the animation (default is 0)
    mobile:       true,       // trigger animations on mobile devices (default is true)
    live:         true,       // act on asynchronously loaded content (default is true)
    callback:     function(box) {
      // the callback is fired every time an animation is started
      // the argument that is passed in is the DOM node being animated
    }
  }
);
wow.init();

   

$(window).on('load resize', function(){

 var reszsc = $(window).width();
 
		$.scrollify({
	section:".section",
    scrollbars:false,
    before:function(i,panels) {
      var ref = panels[i].attr("data-section-name");

      $(".controls .active").removeClass("active");

      $(".controls").find("a[href=#" + ref + "]").addClass("active");
    },
    afterRender:function() {
      var pagination = "<ul class=\"controls\">";

      $(".section").each(function(i) {
        pagination += "<li><a href=\"#" + $(this).attr("data-section-name") + "\"><span class=\"hover-text\">" + $(this).attr("data-section-name").charAt(0).toUpperCase() + $(this).attr("data-section-name").slice(1) + "</span></a></li>";
      });

      pagination += "</ul>";

      $(".home").append(pagination);
    }
  });

  $(".controls a").on("click",$.scrollify.move);		

});


$(".testimonial-slider").owlCarousel({
	navigation : true, // Show next and prev buttons
	loop:true,
	items : 1,
	margin:5,
	nav:false,
	navText: ["",""],	
	autoplay:true,	
	autoplayHoverPause: false,
	paginationSpeed :2000,
	autoplayTimeout:2000,
	smartSpeed:2000,
	navSpeed:2000,
	dotsSpeed:2000,
	autoPlaySpeed:2000,
	dots:true,
	autoHeight:false,	
});

     $(".feedcar").owlCarousel({
 navigation : true, // Show next and prev buttons
	loop:true,
	items : 4,
	margin:5,
	nav:true,
	navText: ["",""],	
	autoplay:true,	
	autoplayHoverPause: false,
	paginationSpeed :2000,
	autoplayTimeout:2000,
	smartSpeed:2000,
	navSpeed:2000,
	dotsSpeed:2000,
	autoPlaySpeed:2000,
	dots:true,
	autoHeight:false,
 
  });


/*===============Sandip===========*/

 




	$('.pull-right .notification').hover(function(){
		$(this).find('.hover-box').addClass('actv');
	},function(){
		$(this).find('.hover-box').removeClass('actv');
	});

		$('.pull-right .chat').hover(function(){
		$(this).find('.hover-box').addClass('actv');
	},function(){
		$(this).find('.hover-box').removeClass('actv');
	});

		$('.pull-right .people').hover(function(){
		$(this).find('.hover-box').addClass('actv');
	},function(){
		$(this).find('.hover-box').removeClass('actv');
	});


	$('.pull-right .btn-signup').on('click', function(){
		$(this).parents('body').find('.signup-popup-section').fadeIn('400');
	});	
	
	//$('.btn-signup').on('click', function(){
//		$(this).parents('body').find('.signup-popup-section').fadeIn('400');
//	});

	$('.pull-right .btn-signin').on('click', function(){
	$(this).parents('body').find('.signin-popup_form_sec').fadeIn('400');
	});

	$('.caption-area .join-us').on('click', function(){
	$(this).parents('body').find('.signup-popup-section').fadeIn('400');
	});

	$('.caption-area .login-btn').on('click', function(){
	$(this).parents('body').find('.signin-popup_form_sec').fadeIn('400');
	});

	$('.main-footer .btn-signup').on('click', function(){
	$(this).parents('body').find('.signup-popup-section').fadeIn('400');
	});







$('.pull-right .btn-signup').on('click', function(){
    $(this).parents('body').append('<div class="active-overlay"> </div>');
});


 $('body').on('click','.active-overlay', function(){
    $(this).hide();
    $(this).parents('body').find('.signup-popup-section').hide();
    $(this).parents('body').removeClass('not-scroll');
    $(this).parents('body').removeClass('remove-overlay');
 });


 $('.pull-right .btn-signin').on('click', function(){
    $(this).parents('body').append('<div class="active-overlay"> </div>');
});


 $('body').on('click','.active-overlay', function(){
    $(this).hide();
    $(this).parents('body').find('.signin-popup_form_sec').hide();
    $(this).parents('body').removeClass('not-scroll');
    $(this).parents('body').removeClass('remove-overlay');
 });


$('.caption-area .join-us').on('click', function(){
    $(this).parents('body').append('<div class="active-overlay"> </div>');
});


 $('body').on('click','.active-overlay', function(){
    $(this).hide();
    $(this).parents('body').find('.signup-popup-section').hide();
    $(this).parents('body').removeClass('not-scroll');
    $(this).parents('body').removeClass('remove-overlay');
 });

 $('.caption-area .login-btn').on('click', function(){
    $(this).parents('body').append('<div class="active-overlay"> </div>');
});


 $('body').on('click','.active-overlay', function(){
    $(this).hide();
    $(this).parents('body').find('.signin-popup_form_sec').hide();
    $(this).parents('body').removeClass('not-scroll');
    $(this).parents('body').removeClass('remove-overlay');
 });

 $('.main-footer .btn-signup').on('click', function(){
    $(this).parents('body').append('<div class="active-overlay"> </div>');
});


 $('body').on('click','.active-overlay', function(){
    $(this).hide();
    $(this).parents('body').find('.signup-popup-section').hide();
    $(this).parents('body').removeClass('not-scroll');
    $(this).parents('body').removeClass('remove-overlay');
 });







 $('.notification').parents('body').addClass('index_class');	


	$(".mCustomScrollbar").mCustomScrollbar({
	theme:"minimal"
});

$(".tool-tip").hover(function(){
	$(this).parents('h1').next('.tooltip_text').fadeIn(400);
},function(){
	$(this).parents('h1').next('.tooltip_text').fadeOut(400);
});


/*===============Sandip============*/

});
	
	
	
	
	
	
	
	
	
	