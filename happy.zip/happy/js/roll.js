
            setTimeout(function hide() {
            $('#msg').fadeOut('fast');
        }, 3000);

       
       
 