<!doctype html>


<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Happy Care</title>
      <link rel="icon" href="images/favicon.ico" type="image/x-icon">
      <link href="style.css" rel="stylesheet" type="text/css">
      <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
   </head>
   <body>
      <section class="login-page-module">
         
         <div class="main-banner">
            <div id="fullpage">
               <div class="section" id="section0" data-section-name="first">
               <header class="main-header">
            <a href="#" class="logo"><img src="images/logo.png" alt=""></a>
            <div class="form-control">
               <div class="input-group">
                  <input type="text" placeholder="Search Happykare">
                  <button type="submit"><img src="images/srch-icon.png" alt=""></button>
               </div>
            </div>
            

        </header>
                  <div class="caption-area">
                     <a href="#" class="big-logo"><img src="images/big-logo.png" alt=""></a>
                     <p>Where Care Meets joy...</p>
                     <h1>The art of child care to assist growth</h1>
                     <a href="#" class="btn join-us">Join Us</a> <a href="#" class="btn login-btn">Login</a>         
                  </div>
                  <footer class="main-footer">
               <ul class="pull-left">
                  <li><a href="#"><i><img src="images/icon1.png" alt=""></i>Newsletter</a></li>
                  <li>
                     <a href="#"><i><img src="images/icon2.png" alt=""></i>Blog</a>
                     <span class="social-icon">
                     <a href="#"><img src="images/fb.png" alt=""></a>
                     <a href="#"><img src="images/rt.png" alt=""></a>
                     <a href="#"><img src="images/in.png" alt=""></a></span>
                  </li>
               </ul>
               <h3><a href="#section1" class="gotosec1">Who We Are?</a></h3>
               <h5>Since you know us now, Then why wait? <a href="#" class="btn-joinus">Join Us</a></h5>
               <ul class="pull-right">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Terms  &amp; Conditions</a></li>
                  <li><a href="#">Contact Us</a></li>
               </ul>
            </footer>
               </div>
               <!--  -->
               <div class="section" id="section1" data-section-name="second">
               <header class="main-header">
            <a href="#" class="logo"><img src="images/logo.png" alt=""></a>
            <div class="form-control">
               <div class="input-group">
                  <input type="text" placeholder="Search Happykare">
                  <button type="submit"><img src="images/srch-icon.png" alt=""></button>
               </div>
            </div>
            <p class="pull-right"><a href="#" class="btn-signup">Sign up</a><a href="#" class="btn-signin">Sign in</a></p>

        </header>
                  <div class="cloud"></div>
                  <div class="wrapper-cloud">
                     <div class="left-image-area">
                        <figure class="cloud-bg">
                           <div class="moon-img wow fadeInLeft" data-wow-duration="1.5s" data-wow-delay="1.5s">
                              <img src="images/moon.png" alt="">
                           </div>
                           <div class="baby-img wow fadeInDown" data-wow-duration="1.5s" data-wow-delay="1.5s">
                              <img src="images/baby.png" alt="">
                           </div>
                        </figure>
                     </div>
                     <div class="right-text-area wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="1.5s">
                        <h2>Hey all Moms and Dads there!</h2>
                        <p>We understand that your job is the most challenging one. We’ll make  it a lot more easier and fun for you. We are an active community to help parents seeking advice or
                           recommendation on child care.
                        </p>
                        <p>Be it about your infant’s  health, your toddler’s schooling, food, clothing, or any related to child care. We are there  to help you!</p>
                     </div>
                  </div>
                  
                  
                  <footer class="main-footer adjustfooter">
               <ul class="pull-left">
                  <li><a href="#"><i><img src="images/icon1.png" alt=""></i>Newsletter</a></li>
                  <li>
                     <a href="#"><i><img src="images/icon2.png" alt=""></i>Blog</a>
                     <span class="social-icon">
                     <a href="#"><img src="images/fb.png" alt=""></a>
                     <a href="#"><img src="images/rt.png" alt=""></a>
                     <a href="#"><img src="images/in.png" alt=""></a></span>
                  </li>
               </ul>
               <h3><a href="#section2" class="gotosec2">How we do this?</a></h3>
               <h5>Since you know us now, Then why wait? <a href="#" class="btn-joinus">Join Us</a></h5>
               <ul class="pull-right">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Terms  &amp; Conditions</a></li>
                  <li><a href="#">Contact Us</a></li>
               </ul>
            </footer>
               </div>
               <!--  -->
               <div class="section" id="section2" data-section-name="third">
               <header class="main-header">
            <a href="#" class="logo"><img src="images/logo.png" alt=""></a>
            <div class="form-control">
               <div class="input-group">
                  <input type="text" placeholder="Search Happykare">
                  <button type="submit"><img src="images/srch-icon.png" alt=""></button>
               </div>
            </div>
            <p class="pull-right"><a href="#" class="btn-signup">Sign up</a><a href="#" class="btn-signin">Sign in</a></p>

        </header>
                  <div class="cloud"></div>
                  <div class="wrapper-cloud">
                     <div class="left-image-area">
                        <figure class="images-area">
                           <div class="toy-img1 wow fadeInRight" data-wow-duration="2.5s" data-wow-delay="2.5s"><img src="images/toys.png" alt=""></div>
                          <div class="bby-img wow zoomIn" data-wow-duration="2.5s" data-wow-delay="2.5s"><img src="images/baby2.png" alt=""></div>
                          <div class="toy-img2 wow fadeInLeft" data-wow-duration="2.5s" data-wow-delay="2.5s"><img src="images/toys_2.png" alt=""></div>
                       </figure>
                     </div>
                     <div class="right-text-area wow fadeInUp" data-wow-duration="2.5s" data-wow-delay="2.5s">
                        <h2>We call this- “Pareting from Experience”</h2>
                        <p>At Happykare, parents sahre thier real time experience on child care. We believe that parenting is an art that can only be learnt from real time experience.</p>
                        <p>So all childcare &amp; parenting tips, baby stories and the cuteness around is here Happykare</p>
                        <h5>“Happy Parents make a happy Family”</h5>
                     </div>
                  </div>
                  <footer class="main-footer adjustfooter2">
               <ul class="pull-left">
                  <li><a href="#"><i><img src="images/icon1.png" alt=""></i>Newsletter</a></li>
                  <li>
                     <a href="#"><i><img src="images/icon2.png" alt=""></i>Blog</a>
                     <span class="social-icon">
                     <a href="#"><img src="images/fb.png" alt=""></a>
                     <a href="#"><img src="images/rt.png" alt=""></a>
                     <a href="#"><img src="images/in.png" alt=""></a></span>
                  </li>
               </ul>
               <h3>Since you know us now, then why wait<a href="#" class="joinus btn-signup">Join Us </a></h3>
               
               <ul class="pull-right">
                  <li><a href="#">About Us</a></li>
                  <li><a href="#">Terms  &amp; Conditions</a></li>
                  <li><a href="#">Contact Us</a></li>
               </ul>
            </footer>
               </div>
            </div>            
         </div>
         
         <div class="controls">
            <ul>
              <li><a href="#first"></a></li>
              <li><a href="#second"></a></li>
              <li><a href="#third"></a></li>
            </ul>
         </div>
      </section>

<!-- =====================Start popup======================== -->

<div class="signup-popup-section">
   <div class="signup-popup_header_link">
      <ul>
         <li><a href="{{ route('redirect') }}"><img src="images/img1.png" alt=""></a></li>
         <li><a href="#"><img src="images/img2.png" alt=""></a></li>
      </ul>
   </div>
   @if(count($errors)>0)
      <div class="row">
         <div class="col-md-6">
            <ul>
               @foreach($errors->all() as $error)
                  <li style="color:red;">{{$error}}</li>
               @endforeach
            </ul>
         </div>
      </div>
   @endif
   <div class="signup-popup_form_sec">
      <h3>or Sign up with</h3>
      <form action="{{ route('signup') }}" method="post">
         <div class="full_width">
            <div class="fild_sec">
               <input type="text" placeholder="First Name" name="first_name" id="first_name" required value="{{Request::old('first_name')}}">
            </div>
            <div class="fild_sec">
               <input type="text" placeholder="Last Name" name="last_name" id="last_name" required value="{{Request::old('last_name')}}">
            </div>
         </div>
         <div class="fild_area">
            <input type="email" placeholder="Email ID" name="email" id="email" required value="{{Request::old('email')}}">
         </div>
         <div class="fild_area">
            <input type="password" placeholder="Password" name="password" id="password" required >
         </div>
         <p>By creating an account, you agree to our <span><a href="#">Terms &amp; Conditions</a></span></p>
         <div class="form_submit">
            <input type="submit" value="Join Us">

         </div>
          <input type="hidden" name="_token" value="{{ Session::token() }}">
      </form>
   </div>
</div>

<div class="signin-popup_form_sec">
   <div class="signin-popup_heading">
      <h2>Sign in</h2>
   </div>   
   @if(count($errors)>0)
      <div class="row">
         <div class="col-md-6">
            <ul>
               @foreach($errors->all() as $error)
                  <li style="color:red;">{{$error}}</li>
               @endforeach
            </ul>
         </div>
      </div>
   @endif
      <div class="signin_form">
         <div class="signin_form_letf">
        
            <form method="POST"   action="{{ route('signin') }}" >
               <div class="full_fild">
                  <input type="email" placeholder="Email id"  name="email" id="email" required value="{{Request::old('first_name')}}">
               </div>
               <div class="full_fild">
                  <input type="password" placeholder="Password" name="password" id="password" required>
               </div>
               <div class="forget_password_submit">
                  <a href="#">Forgot Password?</a>
                  <input type="checkbox"><p>Remember me</p>
                  <input type="submit" value="log in" name="login">
               </div>
               <div class="no-account_sing-up_form">
                  <p>No Account? <a href="#">Sign up</a></p>
               </div>
               <input type="hidden" name="_token" value="{{ Session::token() }}">
               
            </form>
         </div>
         <div class="signin_form_right">
            <a href="#"><img src="images/img1.png" alt=""></a>
            <a href="#"><img src="images/img2.png" alt=""></a>
         </div>
      </div>
</div>

<!-- =====================Start popup======================== -->
      <!--  -->
      <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
      <script src="js/jquery.scrollify.min.js"> </script>
      <script src="js/wow.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/edit-js.js"> </script>
   </body>
</html>