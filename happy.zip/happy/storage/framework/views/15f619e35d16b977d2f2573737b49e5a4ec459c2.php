<!doctype html>
<html>
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Happy Care</title>
      <link rel="icon" href="images/favicon.ico" type="image/x-icon">
      <link href="style.css" rel="stylesheet" type="text/css">
      <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800' rel='stylesheet' type='text/css'>
   </head>
   
   <body>
      <header class="main-header homepage">
            <a href="#" class="logo"><img src="images/logo.png" alt=""></a>
            <div class="form-control">
               <div class="input-group">
                  <input type="text" placeholder="Search Happykare">
                  <button type="submit"><img src="images/srch-icon.png" alt=""></button>
               </div>
            </div>
           
            <P class="userwelcome">Hey, <span><?php echo e(isset(Auth::user()->name) ? Auth::user()->first_name : Auth::user()->first_name); ?> !</span> Good To See You. Hope Your Child Is Doing Great!</P> 

           <div class="pull-right index_page">
           		<div class="notification">
                	<img src="images/notification.png"/>
                  <div class="counter">1</div>
                    <ul class="hover-box mCustomScrollbar">
                      <li><a href="#">Menu Item 1</a></li>
                      <li><a href="#">Menu Item 2</a></li>
                      <li><a href="#">Menu Item 3</a></li>
                      <li><a href="#">Menu Item 4</a></li>
                      <li><a href="#">Menu Item 5</a></li>
                      <li><a href="#">Menu Item 5</a></li>
                    </ul>
                </div>
                <div class="chat">
                	<img src="images/chat.png"/>
                    <div class="counter">1</div>
                    <ul class="hover-box mCustomScrollbar">
                      <li><a href="#">Menu Item 1</a></li>
                      <li><a href="#">Menu Item 2</a></li>
                      <li><a href="#">Menu Item 3</a></li>
                      <li><a href="#">Menu Item 4</a></li>
                      <li><a href="#">Menu Item 5</a></li>
                    </ul>
                </div>

                <div class="people">
                	<img src="images/people.png"/>
                    <ul class="hover-box mCustomScrollbar">
                      <li><a href="#">My Profile</a></li>
                      <li><a href="#">Help</a></li>
                      <li><a href="#">Settings</a></li>
                      <li><a href="<?php echo e(route('logout')); ?>">Log Out</a></li>
                    </ul>
                </div>
           </div>
         </header>
         <section class="3stepcontent">
         	<div class="leftsection">
            	<div class="content-block">
                	<section class="askparent">
                        <div class="user_star">
                            <a class="username" href="#">User Name</a>
                            <ul>
                              <li><a href="#"><img src="images/star.png" alt=""></a></li>
                              <li><a href="#"><img src="images/star.png" alt=""></a></li>
                              <li><a href="#"><img src="images/star.png" alt=""></a></li>
                              <li><a href="#"><img src="images/star.png" alt=""></a></li>
                              <li><a href="#"><img src="images/star.png" alt=""></a></li>
                            </ul>
                            <a class="milestone-achive" href="#">Milestones Achieved</a>
                            <a class="child-growth" href="#">Your Child Growth Timeline</a>
                        </div>
                        <div class="cartoonimage left_cartoonimage">
                            <img src="images/cartoon1.png"/>
                        </div>
                        <p>Ask Other Parents</p>
                        <form method="post">
                            <input type="text" placeholder="Any question on child care" />
                            <input type="submit" class="askme"/>
                        </form>
                      <a href="#" class="viewall">View All Questions By Other Parents</a>
                    </section>
                
                
                </div>
            	<!--<footer class="main-footer homepagefooter">
                	<ul class="pull-left">
                  <li><a href="#"><i><img src="images/icon1.png" alt=""></i>Newsletter</a></li>
                  <li>
                     <a href="#"><i><img src="images/icon2.png" alt=""></i>Blog</a>
                     <span class="social-icon">
                     <a href="#"><img src="images/fb.png" alt=""></a>
                     <a href="#"><img src="images/rt.png" alt=""></a>
                     <a href="#"><img src="images/in.png" alt=""></a></span>
                  </li>
                  </ul>
                </footer>-->
            </div>
            
                <div class="midbody">
               
                <?php if(count($errors)>0): ?>
                  <div class="error" id="msg">
                    <ul>
                      <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                      <?php endforeach; ?>
                    </ul>
                  </div>
                <?php endif; ?>
               
                
              
                <?php if(Session::has('message')): ?>

                  <div class="msg" id="msg">
                    
                    <?php echo e(Session::get('message')); ?>

                    
                  </div>
                <?php endif; ?>
              
                    <div class="postfeed">
                        <h1>Help other parents by posting your<span>TINY FEEDS</span><img class="tool-tip" src="images/icon7.png" alt=""></h1>
                        <div class="tooltip_text">
                          <p>Help Other parents by posting yourTINY FEEDS</p>
                        </div>
                        <form method="post" action="<?php echo e(route('post.create')); ?>">
                        <div class="feedBox">
                            <figure><img src="images/feedpic.png"/></figure>
                            <textarea placeholder="Share your Experience on child care!" name="feedBox"></textarea>
                             <div class="attachment">
                                 <h5 style="text-align:center; color:#969696; ">Select Category</h5> 
                                <select name="categ">
                                     
                                    <option>Feeding & Nursing</option>
                                    <option>Bath & Skin Care</option>
                                    <option>Health & Safety</option>
                                    <option>Baby Gear</option>
                                    
                                </select>
                                 
                                 <div class="uploadimg">
                                    <input type="file"/>
                                 <div class="fileimg"></div>
                                     
                                    
                                 </div>
                                 
                            </div>
                        </div>
                            <input type="submit" class="postfeed2"/>
                           <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">
                        </form>
                    </div>
                    
                    <div class="carouselcategory">
                    
                        <h2>Tiny Feeds by Category</h2>
                        
                        <div class="owl-carousel feedcar">
                        <a href="<?php echo e(route('postsBycateg1')); ?>">
                            <div class="item"> 
                                <img src="images/pic1.png"/>
                                <p>Feeding & Nursing</p>
                            </div>
                         </a> 

                         <a href="<?php echo e(route('postsBycateg2')); ?>">  
                            <div class="item"> 
                                <img src="images/pic2.png"/>
                                <p>Bath & Skin Care</p>
                            </div>
                            </a>

                            <a href="postsBycateg3">
                            <div class="item"> 
                                <img src="images/pic3.png"/>
                                <p>Health & Safety</p>
                            </div>
                            </a>

                            <a href="postsBycateg4">
                            
                            <div class="item"> 
                                <img src="images/pic4.png"/>
                                <p>Baby Gear</p>
                            </div>
                            </a>

                            <a href="<?php echo e(route('postsBycateg1')); ?>">
                            <div class="item"> 
                                <img src="images/pic1.png"/>
                                <p>Feeding & Nursing</p>
                            </div>
                            </a>
                            
                            <a href="<?php echo e(route('postsBycateg2')); ?>">
                            
                            <div class="item"> 
                                <img src="images/pic2.png"/>
                                <p>Bath & Skin Care</p>
                            </div>
                            </a>

                            <a href="postsBycateg3">
                            
                            <div class="item"> 
                                <img src="images/pic3.png"/>
                                <p>Health & Safety</p>
                            </div>
                            </a>

                            <a href="postsBycateg4">
                            
                            <div class="item"> 
                                <img src="images/pic4.png"/>
                                <p>Baby Gear</p>
                            </div>
                            </a>
                        </div>
                        
                    </div>
                    
                   <div class="trendingfeed">
                    
                      <h2>Trending Tiny Feeds</h2>
                      </br>
                       
                       <?php if(count($posts)==0): ?>

                                 <h2>No posts in this category!!</h2>
                               
                               <?php endif; ?>
                       <?php foreach($posts as $post): ?>
                       <ul class="cluthline">
                        <li>
                           <div class="topPost">
                                <img src="images/user1.png"/>
                               <p><?php echo e($post->body); ?></p>
                               <div class="readmoreblock">
                                    <span>- By <samp><?php echo e($post->user['first_name']); ?></samp></span>
                                   <a href="">Read More</a>
                               </div>
                            </div>
                            <div class="bottompost">
                                <div class="leftshare">
                                    <a href=""><img src="images/like.png" align="absmiddle"/>Like</a>
                                    <a href=""><img src="images/comment.png" align="absmiddle"/>Comment</a>
                                    <a href=""><img src="images/share.png" align="absmiddle"/>Share</a>
                                    <a href=""><img src="images/follow.png" align="absmiddle"/>Follow user</a>
                                </div>
                                <div class="rightshare">
                                    <a href=""><img src="images/clock.png" align="absmiddle"/><?php echo e($post->created_at); ?></a>
                                    
                                
                                </div>
                            </div>
                           
                           </li>
                           
                           
                             
                       </ul>
                       <?php endforeach; ?>
                       
                       
                       <a href="" class="alltiny" style="visibility:hidden;"><img src="images/tinyfeeds.png"/></a>
                    </div> 
                    
                    
                </div>
               <div class="leftsection">
            	<div class="content-block">
                	<section class="askparent">
                        <div class="cartoonimage">
                            <img src="images/parent.png"/>
                        </div>
                        <p>Featuring super parents</p>
                       <ul class="userprofile">
                       		<li>
                            	<div class="numberblock">
                                	<p>1</p>
                                </div>
                                
                                <div class="userBlock">
                                	<figure><img src="images/pic-1.png"/></figure>
                                    <div class="pinkbrigade"><a href="#">User Profile</a></div>
                                </div>
                            </li>
                            <li>
                            	<div class="numberblock">
                                	<p>2</p>
                                </div>
                                
                                <div class="userBlock">
                                	<figure><img src="images/pic-1.png"/></figure>
                                    <div class="pinkbrigade"><a href="#">User Profile</a></div>
                                </div>
                            </li>
                            <li>
                            	<div class="numberblock">
                                	<p>3</p>
                                </div>
                                
                                <div class="userBlock">
                                	<figure><img src="images/pic-1.png"/></figure>
                                    <div class="pinkbrigade"><a href="#">User Profile</a></div>
                                </div>
                            </li>
                            
                       
                       </ul>
                    </section>
                
                
                </div>
            	<!--<footer class="main-footer homepagefooter">
                	<ul class="pull-left">
                  <li><a href="#">About</a></li>
                  <li><a href="#">Terms & conditions</a></li>
                  <li><a href="#">Contact us</a></li>
                  
                  </ul>
                </footer>-->
            </div> 
         
         </section>
      
      
      <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
      <script src="js/jquery.scrollify.min.js"> </script>
      <script src="js/wow.min.js"></script>
      <script src="js/owl.carousel.min.js"></script>
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/edit-js.js"> </script>
      <script src="js/roll.js"> </script>
   </body>
</html>